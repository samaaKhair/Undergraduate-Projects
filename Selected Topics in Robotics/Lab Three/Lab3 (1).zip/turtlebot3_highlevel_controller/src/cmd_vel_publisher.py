#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

def velocity_publisher():
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=5)
    rospy.init_node('cmd_vel_publisher_node', anonymous=True)
    rate = rospy.Rate(5)  # 5 Hz

    while not rospy.is_shutdown():
        cmd = Twist()
        cmd.linear.x = 0.4  # Move forward
        cmd.angular.z = -0.1  # Slight counter rotation
        pub.publish(cmd)
        rate.sleep()

if __name__ == '__main__':
    try:
        velocity_publisher()
    except rospy.ROSInterruptException:
        pass

