#!/usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan

def scan_callback(data):
    min_dist = min(data.ranges)
    rospy.loginfo("Minimum distance recorded: %f", min_dist)

def listener_node():
    rospy.init_node('scan_listener_node', anonymous=True)
    rospy.Subscriber("/scan", LaserScan, scan_callback)
    rospy.spin()

if __name__ == '__main__':
    listener_node()

