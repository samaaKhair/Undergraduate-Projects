#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

def move_turtle():
    rospy.init_node('turtle_driver', anonymous=True)
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(10)  # 10hz
    command = Twist()
    command.linear.x = 1.5
    command.angular.z = 0.7

    while not rospy.is_shutdown():
        rospy.loginfo("Commanding turtle to move")
        pub.publish(command)
        rate.sleep()

if __name__ == '__main__':
    try:
        move_turtle()
    except rospy.ROSInterruptException:
        pass

