#!/usr/bin/env python

import rospy
from turtlesim.msg import Pose
from std_msgs.msg import Color

def pose_callback(data):
    rospy.loginfo("Turtle Position - x: %f, y: %f, theta: %f", data.x, data.y, data.theta)

def color_callback(data):
    rospy.loginfo("Turtle Color - red: %d, green: %d, blue: %d", data.r, data.g, data.b)

def listener():
    rospy.init_node('turtle_status_listener', anonymous=True)
    rospy.Subscriber('/turtle1/pose', Pose, pose_callback)
    rospy.Subscriber('/turtle1/color_sensor', Color, color_callback)
    rospy.spin()

if __name__ == '__main__':
    listener()

