#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
import openai
from transformers import pipeline
import requests

# Initialize Sentiment Analysis Pipeline
sentiment_analysis = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")

# OpenAI API Key
openai.api_key = "your-openai-api-key"  # Replace with your OpenAI API key

def analyze_sentiment(text):
    result = sentiment_analysis(text)
    return result[0]

def determine_personality(sentiment):
    if sentiment['label'] == 'POSITIVE':
        return 'Friendly'
    elif sentiment['label'] == 'NEGATIVE':
        return 'Empathetic'
    else:
        return 'Professional'

def generate_reply(personality, emotion, input_text):
    headers = {
        "Authorization": f"Bearer {openai.api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "gpt-3.5-turbo",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant named Noor, a robot in Zewail City."},
            {"role": "user", "content": f"Respond to the following text in a {personality} and {emotion} manner:\n\nUser: {input_text}\nBot:"}
        ],
        "max_tokens": 150,
        "temperature": 0.7
    }
    response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=data)
    response.raise_for_status()
    return response.json()['choices'][0]['message']['content']

class ChatBotNode:
    def __init__(self):
        self.sub = rospy.Subscriber('transcribed_speech', String, self.callback)
        self.pub = rospy.Publisher('prompt', String, queue_size=10)

    def callback(self, data):
        transcribed_text = data.data
        rospy.loginfo(f"Received Transcribed Speech: {transcribed_text}")

        sentiment = analyze_sentiment(transcribed_text)
        personality = determine_personality(sentiment)

        emotion_map = {
            'POSITIVE': 'happy',
            'NEGATIVE': 'sad',
            'NEUTRAL': 'neutral'
        }
        emotion = emotion_map[sentiment['label']]

        reply = generate_reply(personality, emotion, transcribed_text)
        rospy.loginfo(f"Publishing Reply: {reply}")
        self.pub.publish(reply)

def main():
    rospy.init_node('chatbot_node')
    chatbot = ChatBotNode()
    try:
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

if __name__ == '__main__':
    main()
