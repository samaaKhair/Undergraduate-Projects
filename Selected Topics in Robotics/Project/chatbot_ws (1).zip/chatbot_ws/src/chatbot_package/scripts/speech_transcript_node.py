#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
import whisper

def transcribe_audio():
    model = whisper.load_model("large")
    filename = "/path/to/your/audio.wav"  # Replace with actual path
    result = model.transcribe(filename)
    return result['text']

def speech_transcript_node():
    rospy.init_node('speech_transcript_node')
    pub = rospy.Publisher('transcribed_speech', String, queue_size=10)
    rate = rospy.Rate(0.1)  # Publish at 0.1 Hz, adjust as necessary

    while not rospy.is_shutdown():
        # Simulate getting audio and transcribing it
        transcribed_text = transcribe_audio()
        rospy.loginfo(f"Publishing Transcribed Speech: {transcribed_text}")
        pub.publish(transcribed_text)
        rate.sleep()

if __name__ == '__main__':
    try:
        speech_transcript_node()
    except rospy.ROSInterruptException:
        pass
