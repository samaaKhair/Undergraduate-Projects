#!/usr/bin/env python3

import rospy

def main():
    rospy.init_node('minimal_node', anonymous=True)
    rospy.loginfo("Minimal node is running")
    rospy.spin()

if __name__ == '__main__':
    main()
